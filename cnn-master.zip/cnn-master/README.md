# cnn
new wheel about cnn in java

learn from:
    * https://github.com/BigPeng/JavaCNN
