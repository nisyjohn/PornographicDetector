<p>The dataset is part of MNIST from kaggle Digit Recognizer competition. </p>
<p>"train.format" is the train set, which has been binarized.</p>
<p>"test.format" is the test set, which has been binarized.</p>